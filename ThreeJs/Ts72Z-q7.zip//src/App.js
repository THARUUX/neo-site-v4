import React, { Component } from "react";
import "./App.css";
import ThreeJSExample from "./ThreeJSExample";

export default class App extends Component {
  render() {
    return (
      <div className="container">
        <ThreeJSExample />
      </div>
    );
  }
}
